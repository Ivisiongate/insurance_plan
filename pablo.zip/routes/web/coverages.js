const getSRF = require('../../helpers/sort-range-filters');
const setContentRange = require('../../helpers/content-range');
const db = require('../../helpers/db');

const coverages = (router) => {

    router.get('/coverages', async (req,res)=>{

        const {sort,range,filter} = getSRF(req.query);

        let coverages = await db('coverages').orderBy(sort[0],sort[1]);
        
        if ( filter && filter.q ){
            coverages = await db('coverages').whereRaw(`LOWER(name) LIKE ?`, [`%${filter.q.toLowerCase()}%`]).orderBy(sort[0],sort[1]);
        }
    
        res = setContentRange(res,range,coverages);
        
        res.status(200).send({status: true, message: 'coverages listed successfully',data: coverages});
    });

    return router;
}

module.exports = coverages;