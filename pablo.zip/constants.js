module.exports = {
    BASE_URL: process.env.BASE_URL || 'https://www.pablobackend.cotizandotuplandeisapre.cl',
    JWT_SECRET: process.env.JWT_SECRET || '7w!z%C*F-JaNdRgUkXp2s5u8x/A?DG+KbPeShVmYq3t6w9y$B&EH@McQfTjWnZ' 
}